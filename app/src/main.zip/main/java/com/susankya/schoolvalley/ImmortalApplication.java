package com.susankya.schoolvalley;

import android.support.multidex.MultiDexApplication;

import java.util.ArrayList;

/**
 * Created by Aditya on 12/26/2016.
 */
public class ImmortalApplication extends MultiDexApplication {
    private static ImmortalApplication abc;

    public static String getTheSN() {
        return theSN;
    }

    public static void setTheSN(String theSN) {
        ImmortalApplication.theSN = theSN;
    }

    public static String theSN;
    public static String beforeLoginSN,bLSName,bLdbName;
    public static notice clickedNotice;
    public static String category;
    public ArrayList<GalleryItem> galleryItemArrayList;
    public ImmortalApplication getInstance(){
        return abc;
    }
    @Override
    public void onCreate() {
        super.onCreate();

        abc = this;
    }

    public void set(String SN,String sName,String dbName,String category)
    {
        beforeLoginSN=SN;
        bLSName=sName;
        bLdbName=dbName;
        ImmortalApplication.category=category;
    }
}

