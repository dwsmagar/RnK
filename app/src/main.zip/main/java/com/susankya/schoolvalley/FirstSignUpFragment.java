package com.susankya.schoolvalley;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import com.google.firebase.iid.FirebaseInstanceId;

import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONTokener;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import butterknife.BindView;
import butterknife.ButterKnife;


public class FirstSignUpFragment extends android.support.v4.app.Fragment implements FragmentCodes {
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";
    private UserInfo userInfo;
    private String mParam1;
    private boolean checked=false;
    private String mParam2;

    public String[] collegeNames,databaseNames;
    ArrayList<String> collegeNameArray=new ArrayList<>(),databaseNameArray=new ArrayList<>();
    int userNum;
    SQLiteHelper sqLiteHelper;
    String mobileNumber;
    String selectedDB;
    @BindView(R.id.mobileNum)EditText mobileNumET;
    SQLiteDatabase db;
    String institution;
  @BindView(R.id.toolbar)  Toolbar toolbar;
   public static TextViewPlus selectedInst;
    public static int chosen=0;
    String collegeSN;
    @BindView(R.id.genderRadio)RadioGroup radioGroup;
    @BindView(R.id.male)RadioButton male;
    @BindView(R.id.female)RadioButton female;
    String link= FragmentCodes.MAIN_DATABASE+"users/SignUp.php";
    private EditText mUsername,mPassword,mConfirmPassword,mFirstName,mLastName;
    private int isUsernameEmpty=0,isPasswordEmpty=0,isPasswordNotMatching=0,isFullNameEmpty=0,isFirstNameEmpty=0,isLastNameEmpty=0;
    private Button mSignUp;
    String username,fullName,password,confirmPassword;
    @BindView(R.id.field1)EditText field1;
    @BindView(R.id.field2)EditText field2ET;
    @BindView(R.id.roll_number)EditText rollET;
    String firstName,lastName;

    public static FirstSignUpFragment newInstance(String param1, String param2) {
        FirstSignUpFragment fragment = new FirstSignUpFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    public FirstSignUpFragment() {
        // Required empty public constructor
    }



    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            //Toast.makeText(getActivity(),currentActivity+"SIGN",Toast.LENGTH_LONG).show();
        }
        sqLiteHelper=new SQLiteHelper(getActivity());
        db=sqLiteHelper.getWritableDatabase();
        db.execSQL(
                "create table if not exists " + USERS_TABLE + " ( " + C_SN + " integer primary key autoincrement," +
                        USER_NO + " int (10)," + FIRST_NAME + " varchar(100)," + LAST_NAME + " varchar(100)," +
                        PASSWORD + " varchar(100)," + USERNAME + " varchar(50)," +
                        VERIFIED + " int(1)," + INSTITUTION + " varchar," + LEVEL + " varchar, " +
                        DBNAME + " varchar," +
                        GENDER + " varchar(50)," + PROFILE_PIC_LOCATION + " varchar," + LOCATION + " varchar,"
                        + PHONE_NUMBER + " int(10), " + INTEREST + " varchar, " + HOBBY + " varchar);"

        );
        if(StudentInActivity.searchItemArrayList!=null)
        StudentInActivity.searchItemArrayList.clear();
        loadCollegeList();
    }

    @BindView(R.id.field2line)TextViewPlus field2line;
    String category;
    private void checkCategory()
    {
        String c=ImmortalApplication.category.toLowerCase();
        category=c;
        rollET.setHint("Roll number (Optional)");
        switch (c)
        {
            case "+2 college":
                field1.setHint("Section");
                return;
            case "school":
                field1.setHint("Class");
                return;
            case "bachelors college":
                field1.setHint("Faculty");
                field2ET.setVisibility(View.VISIBLE);
                field2line.setVisibility(View.VISIBLE);
                field2ET.setHint("Semester");
                return;
            case "consultancy":
                field1.setHint("Faculty");
                field2ET.setHint("Section");
                field2ET.setVisibility(View.VISIBLE);
                field2line.setVisibility(View.VISIBLE);
                return;
            case "others":
                field1.setHint("Section");
                return;
            case "":
                field1.setVisibility(View.GONE);
        }
    }
    private void fieldsCheck()
    {
        if(username.isEmpty())
        {
            isUsernameEmpty=1;
            mUsername.setError("This field cannot be empty");

        }
        else
            isUsernameEmpty=0;

        if(mobileNumber.isEmpty())
        {

            mobileNumET.setError("This field cannot be empty");
        }
        if(firstName.isEmpty())
        {
            isFirstNameEmpty=1;
            mFirstName.setError("This field cannot be empty");

        }
        else isFirstNameEmpty=0;
        if(lastName.isEmpty())
        {
            isLastNameEmpty=1;
            mLastName.setError("This field cannot be empty");

        }
        else isLastNameEmpty=0;
        if(password.isEmpty())
        {
            isPasswordEmpty=1;
            mPassword.setError("This field cannot be empty");

        }
        else  isPasswordEmpty=0;
        if(field1.getText().toString().isEmpty())
        {
            field1.setError("This field cannot be empty");
        }
        if(rollET.getText().toString().isEmpty())
        {
            rollET.setError("This field cannot be empty");
        }

        if((!(password.equals(confirmPassword))))
        {
            isPasswordNotMatching=1;
            if(isPasswordEmpty==1)
                ;
            else
                mConfirmPassword.setError("Passwords do not match.");

        }
        else isPasswordNotMatching=0;
    }

    private boolean arePasswordsMatching()
    {

            if(password.equals(confirmPassword)) return true;
            else return false;

    }

    public void loadCollegeList()
    {
        String res= UtilitiesAdi.loadJSON(getActivity().getApplicationContext(), "collegelist");
        try
        {
            JSONArray jsonArray=(JSONArray) new JSONTokener(res).nextValue();
            collegeNames=new String[jsonArray.length()];
            databaseNames=new String[jsonArray.length()];
            for(int i=0;i<jsonArray.length();i++)
            {

                JSONObject jsonObject=jsonArray.getJSONObject(i);
                String collegeName=jsonObject.getString("college_name");
                String databaseName=jsonObject.getString("database_name");
                SearchItem s=new SearchItem();
                s.name=collegeName;
                String sn=jsonObject.getString("sn");
                s.collegeSN=Integer.parseInt(sn);
                s.location=jsonObject.getString("location");
                StudentInActivity.searchItemArrayList.add(s);
                collegeNames[i]=collegeName;
                databaseNames[i]=databaseName;
                collegeNameArray.add(collegeName);
                databaseNameArray.add(databaseName);

            }
        }

        catch (Exception e)
        {

        }

    }


    public class UsernameValidator{

        private Pattern pattern;
        private Matcher matcher;

        private static final String USERNAME_PATTERN = "(?:[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*|\"(?:[\\x01-\\x07\\x0b\\x0c\\x0e-\\x1f\\x21\\x23-\\x5b\\x5d-\\x7f]|\\\\[\\x01-\\x09\\x0b\\x0c\\x0e-\\x7f])*\")@(?:(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?|\\[(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?|[a-z0-9-]*[a-z0-9]:(?:[\\x01-\\x08\\x0b\\x0c\\x0e-\\x1f\\x21-\\x5a\\x53-\\x7f]|\\\\[\\x01-\\x09\\x0b\\x0c\\x0e-\\x7f])+)\\])";

        public UsernameValidator(){
            pattern = Pattern.compile(USERNAME_PATTERN);
        }


        public boolean validate(final String username){

            matcher = pattern.matcher(username);
            return matcher.matches();

        }
    }
    public boolean isUsernameValid()
    {
        if(username.length()<6)
            return false;
        else return true;
    }
    public boolean isPasswordValid()
    {
        if(password.length()<6)
            return false;
        else return true;
    }
    public void getLevelList()
    {
        String link="http://46.101.81.232/App/New App/ChhalFaal/Profile/level.php";
        link= Utilities.makeUrl(link);

        new PhpConnect(link,"Almost done",getActivity(),1,new String[]{CMDXXX},new String[]{"cmdxxx"}).setListener(new PhpConnect.ConnectOnClickListener() {
            @Override
            public void onConnectListener(String res) {
                try {
                    JSONArray JA = (JSONArray) new JSONTokener(res).nextValue();
                    String[] strings = new String[JA.length()];
                    for (int i = 0; i < JA.length(); i++) {
                        strings[i] = JA.getString(i);
                    }
                    Set set = new HashSet(Arrays.asList(strings));
                    getActivity().getSharedPreferences(FragmentCodes.PUBLIC_SHAREDPREFERENCE, Context.MODE_PRIVATE).edit().putStringSet("levels", set).apply();
                    getActivity().getSharedPreferences(FragmentCodes.PUBLIC_SHAREDPREFERENCE, Context.MODE_PRIVATE).edit().putBoolean("hasGotLevel", true).apply();
                   // loadCollegeList();
                } catch (Exception e) {
                }
            }
        });
    }

    public void getCollegeList()
    {
        String link="http://46.101.81.232/App/New%20App/Android%20Call/Call%20Main%20Database/institutionNames.php";
        new PhpConnect(link,"Preparing. Please wait...",getActivity(),1,new String[]{"2568wwexve"},new String[]{"cmdxxx"}).setListener(
                new PhpConnect.ConnectOnClickListener() {
                    @Override
                    public void onConnectListener(String res) {

                        UtilitiesAdi.saveJSON(getActivity(), res, "collegelist");
                        UtilitiesAdi.setBoolean(getActivity(), FragmentCodes.COLLEGE_LIST_LOADED, true);
                        // Toast.makeText(StudentInActivity.this,res,Toast.LENGTH_LONG).show();
                        //Log.d("cmdxxx", res);
                        //[{"college_name":"test","database_name":"Susankyatest"},{"college_name":"susankya","database_name":"Susankyaaditya"}]
                        try {
                            JSONArray jsonArray = (JSONArray) new JSONTokener(res).nextValue();
                            collegeNames = new String[jsonArray.length()];
                            databaseNames = new String[jsonArray.length()];
                            for (int i = 0; i < jsonArray.length(); i++) {
                                JSONObject jsonObject = jsonArray.getJSONObject(i);
                                String collegeName = jsonObject.getString("college_name");
                                String databaseName = jsonObject.getString("database_name");
                                collegeNames[i] = collegeName;
                                databaseNames[i] = databaseName;
                                collegeNameArray.add(collegeName);
                                databaseNameArray.add(databaseName);
                            }
                            getLevelList();

                        } catch (Exception e) {

                        }
                    }
                }
        );
    }

    String field1v,field2v;
    @BindView(R.id.gobacktv)TextViewPlus goBack;

    UsernameValidator usernameValidator;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View v=inflater.inflate(R.layout.fragment_first_signup, container, false);
        ButterKnife.bind(this, v);

        if (getActivity().getSharedPreferences("visitedOnce",Context.MODE_PRIVATE).getBoolean("visited",false)){
            getCollegeList();
        }
        usernameValidator=new UsernameValidator();
        toolbar.setTitle("Create account");
        checkCategory();
        goBack.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        getActivity().finish();
                    }
                }
        );
        mUsername=(EditText)v.findViewById(R.id.fragment_signup_username);
        mFirstName=(EditText)v.findViewById(R.id.fragment_signup_firstname);
        mLastName=(EditText)v.findViewById(R.id.fragment_signup_lastname);
        mPassword=(EditText)v.findViewById(R.id.fragment_signup_password);
        selectedInst=(TextViewPlus)v.findViewById(R.id.college_spinner);
        selectedInst.setText(((ImmortalApplication)getActivity().getApplication()).bLSName);
        mConfirmPassword=(EditText)v.findViewById(R.id.fragment_signup_confirm_password);
        mSignUp=(Button)v.findViewById(R.id.fragment_signup_signup);
        mSignUp.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        username=mUsername.getText().toString().trim().toLowerCase();
                        firstName=mFirstName.getText().toString().trim();
                        lastName=mLastName.getText().toString().trim();
                        field1v=field1.getText().toString().trim();
                        field2v=field2ET.getText().toString().trim();
                        password=mPassword.getText().toString();
                        institution=((ImmortalApplication)getActivity().getApplication()).bLSName;
                        collegeSN=((ImmortalApplication)getActivity().getApplication()).beforeLoginSN;
                        mobileNumber=mobileNumET.getText().toString();
                        confirmPassword=mConfirmPassword.getText().toString();
                        link= Utilities.encodeLinkSpace(link);
                        String[] strings;
                        EditText[] editTexts;
                        if(field2ET.getVisibility()!=View.GONE)
                        {
                            strings=new String[]{FragmentCodes.FIELD_EMPTY, FragmentCodes.FIELD_EMPTY, FragmentCodes.FIELD_EMPTY, FragmentCodes.FIELD_EMPTY, FragmentCodes.FIELD_EMPTY,FIELD_EMPTY,FIELD_EMPTY};
                            editTexts=new EditText[]{mUsername,mFirstName,mLastName,mPassword,mobileNumET,field1,field2ET};
                        }
                        else
                        {
                            strings=new String[]{FragmentCodes.FIELD_EMPTY, FragmentCodes.FIELD_EMPTY, FragmentCodes.FIELD_EMPTY, FragmentCodes.FIELD_EMPTY, FragmentCodes.FIELD_EMPTY,FIELD_EMPTY};
                            editTexts=new EditText[]{mUsername,mFirstName,mLastName,mPassword,mobileNumET,field1};
                        }

                        if(new BlankEditText(strings,editTexts).areAllFieldsOK())
                        {
                            if(arePasswordsMatching())
                            {
                                if(isUsernameValid()) {

                                    if (!usernameValidator.validate(username))
                                        Toast.makeText(getActivity(), "Your email is not valid. Please enter full email address", Toast.LENGTH_SHORT).show();

                                }

                                if(isPasswordValid())
                                {

                                }
                                    else Toast.makeText(getActivity(),"Your password should be of minimum 6 characters long",Toast.LENGTH_SHORT).show();

                                if(isUsernameValid() && isPasswordValid() && usernameValidator.validate(username))
                                {
                                    if(checked)
                                    {
                                        institution="Not Selected";
                                        selectedDB="none";
                                    }
                                    callPhp();
                                }
                            }
                            else mConfirmPassword.setError("Passwords do not match");


                        }

                    }
                }
        );

        return v;
    }



    String place1,place2;
    String placeholders[],parameters[];
    void callPhp()
    {
        String gender="";
        String token= FirebaseInstanceId.getInstance().getToken();
        String schoolPlace[]=new String[]{"firstName","lastName","userid","password","cmdxxx","phone_number","college_sn","section","roll","regId","class"};
        String schoolPara[]=new String[]{firstName,lastName,username,password,CMDXXX,mobileNumber,collegeSN, field1.getText().toString(),rollET.getText().toString(),token,field1.getText().toString().trim()};
        String plus2place[]=new String[]{"firstName","lastName","userid","password","cmdxxx","phone_number","college_sn","section","roll","regId","section"};
        String plus2para[]=new String[]{firstName,lastName,username,password,CMDXXX,mobileNumber,collegeSN, field1.getText().toString(),rollET.getText().toString(),token,field1.getText().toString().trim()};
        String bachelorsplace[]=new String[]{"firstName","lastName","userid","password","cmdxxx","phone_number","college_sn","roll","regId","faculty","semester"};
        String bachelorspara[]=new String[]{firstName,lastName,username,password,CMDXXX,mobileNumber,collegeSN,rollET.getText().toString(),token,field1.getText().toString().trim(),field2ET.getText().toString().trim()};
        String consultancyplace[]=new String[]{"firstName","lastName","userid","password","cmdxxx","phone_number","college_sn","roll","regId","section","faculty"};
        String consultancypara[]=new String[]{firstName,lastName,username,password,CMDXXX,mobileNumber,collegeSN,rollET.getText().toString(),token,field1.getText().toString().trim(),field2ET.getText().toString().trim()};
        String othersplace[]=new String[]{"firstName","lastName","userid","password","cmdxxx","phone_number","college_sn","roll","regId","section"};
        String otherspara[]=new String[]{firstName,lastName,username,password,CMDXXX,mobileNumber,collegeSN, rollET.getText().toString(),token,field1.getText().toString().trim()};
        if(category.equals("+2 college"))
        {
            placeholders=plus2place;
            parameters=plus2para;
        }
        else if(category.equals("school"))
        {
            placeholders=schoolPlace;
            parameters=schoolPara;

        }
        else if(category.equals("bachelors college"))
        {
            placeholders=bachelorsplace;
            parameters=bachelorspara;
        }
        else if(category.equals("consultancy"))
        {
            placeholders=consultancyplace;
            parameters=consultancypara;
        }
        else{
            placeholders=othersplace;
        parameters=otherspara;
        }
        int ID=radioGroup.getCheckedRadioButtonId();
        if(ID== R.id.male)
            gender="m";
        else
            gender="f";
        new PhpConnect(link,"Please wait...",getActivity(),1, parameters,placeholders).setListener(
                new PhpConnect.ConnectOnClickListener() {
                    @Override
                    public void onConnectListener(String res) {
                        if(res.trim().equals("0"))
                        {
                            new AlertDialogBuilder("Email exists","Please enter a different email address and try again.","OK","",getActivity());
                        }
                        else if(res.trim().equals("0p"))
                        {
                            mobileNumET.setText("");
                            mobileNumber="";
                            new AlertDialogBuilder("Invalid mobile number","Please enter a valid mobile number and try again.","OK","",getActivity());
                        }
                        else
                        {
                            SharedPreferences sp=getActivity().getApplicationContext().getSharedPreferences("dbName", Context.MODE_PRIVATE);
                            SharedPreferences.Editor editor=sp.edit();
                            editor.putBoolean("collegeSelected", true);
                            editor.putBoolean("signedUp",true);
                            SharedPreferences sps=getActivity().getApplicationContext().getSharedPreferences("visitedOnce", Context.MODE_PRIVATE);
                            SharedPreferences.Editor editor1=sps.edit();
                            editor1.putBoolean("visited",true);
                            editor1.putBoolean("loggedIn",true);
                            editor1.commit();
                            if(selectedInst.getText().equals("None"))
                            {
                                editor.putBoolean("collegeValid",false);
                            }
                            else
                                editor.putBoolean("collegeValid",true);
                            editor.commit();
                            String token=FirebaseInstanceId.getInstance().getToken();
                            String loginLink= Utilities.encodeLinkSpace(FragmentCodes.MAIN_DATABASE + "users/login.php");
                            PhpConnect phpConnect=new PhpConnect(loginLink,"Logging in...",getActivity(),1,
                                    new String[]{username,password,"2568wwexve",token},
                                    new String[]{"userid","password","cmdxxx","regId"});
                            phpConnect.setListener(
                                    new PhpConnect.ConnectOnClickListener() {
                                        @Override
                                        public void onConnectListener(String res) {
                                            try {

                                                JSONObject jO = new JSONObject(res);
                                                userNum = jO.getInt("user_no");
                                                String firstName = jO.getString("firstName");
                                                String lastName = jO.getString("lastName");
                                                String collegeSN=jO.getString("college_sn");
                                                String section=jO.getString("section");
                                                String roll=jO.getString("roll");

                                                userInfo = new UserInfo();
                                                userInfo.setUserNumber(userNum);
                                                userInfo.setFirstName(firstName);
                                                userInfo.setLastName(lastName);
                                                userInfo.collegeSN=collegeSN;
                                                userInfo.roll=roll;
                                                userInfo.section=section;
                                                userInfo.setUserName(username);
                                                userInfo.setPassword(password);
                                                if (!jO.isNull("verified"))
                                                    userInfo.setVerified(jO.getInt("verified"));
                                                else
                                                    userInfo.setVerified(0);
                                                if (!jO.isNull("college_name"))
                                                    userInfo.setInstitution(jO.getString("college_name"));
                                                else
                                                    userInfo.setInstitution("null");
                                                if (!jO.isNull("level"))
                                                    userInfo.setLevel(jO.getString("level"));
                                                else
                                                    userInfo.setLevel("null");
                                                if (!jO.isNull("dbName"))
                                                    userInfo.setDbName(jO.getString("dbName"));
                                                else
                                                    userInfo.setDbName("null");
                                                if (!jO.isNull("gender"))
                                                    userInfo.setGender(jO.getString("gender"));
                                                else
                                                    userInfo.setGender("null");
                                                if (!jO.isNull("profile_pic_location"))
                                                    userInfo.setProfilepiclocation(jO.getString("profile_pic_location"));
                                                else
                                                    userInfo.setProfilepiclocation("null");
                                                if (!jO.isNull("phone_number"))
                                                    userInfo.setPhoneNumber(Integer.toString(jO.getInt("phone_number")));
                                                else
                                                    userInfo.setPhoneNumber("0");
                                                if (!jO.isNull("location"))
                                                    userInfo.setLocation(jO.getString("location"));
                                                else
                                                    userInfo.setLocation("null");
                                                if (!jO.isNull("cover_pic"))
                                                    userInfo.coverPic=jO.getString("cover_pic");

                                                if (!jO.isNull("college_sn"))
                                                    userInfo.setCollegeSN(jO.getString("college_sn"));

                                                userInfo.setBlocked(jO.getInt("blocked"));
                                                userInfo.setFullName(userInfo.getFirstName() + " " + userInfo.getLastName());
                                                sqLiteHelper.insertUser(userInfo);
                                                getActivity().getSharedPreferences(PUBLIC_SHAREDPREFERENCE,Context.MODE_PRIVATE).edit()
                                                        .putString(StudentProfileFragment.TAG_FOR_USER_DETAIL_JSON,res).commit();
                                            } catch (Exception e) {
                                                //Log.d("erroryaha", e.toString());
                                                userInfo = new UserInfo(0, "0");
                                            }

                                            if (userInfo.getUserNumber() == 0) {

                                                new AlertDialogBuilder("Incorrect username or password", "Incorrect username or password. Please try again.", "OK", "", getActivity());
                                            } else {
                                                Utilities.saveUserInfo(username, userInfo.getFullName(), userInfo.getUserNumber(), userInfo.getLevel(), userInfo.getInstitution(), userInfo.getGender(), getActivity());
                                                SharedPreferences sharedPreferences1 = getActivity().getApplicationContext().getSharedPreferences("rememberlogin", Context.MODE_PRIVATE);
                                                SharedPreferences.Editor editor1 = sharedPreferences1.edit();
                                                editor1.putBoolean("isloggedin", true);
                                                editor1.commit();
                                                SharedPreferences sharedPreferences = getActivity().getApplicationContext().getSharedPreferences("userinfo", Context.MODE_PRIVATE);
                                                SharedPreferences.Editor editor = sharedPreferences.edit();
                                                editor.putString("firstName", userInfo.getFirstName());
                                                editor.putString("lastName", userInfo.getLastName());
                                                editor.putString("level", userInfo.getLevel());
                                                editor.putString("institution", userInfo.getInstitution());
                                                editor.putInt("blocked",userInfo.getBlocked());
                                                editor.putString("gender", userInfo.getGender());
                                                editor.putString("fullName", userInfo.getFullName());
                                                editor.putInt("number", userInfo.getUserNumber());
                                                editor.putString("mobile", userInfo.getPhoneNumber());
                                                editor.putString("section",userInfo.section);
                                                editor.putString("roll",userInfo.roll);
                                                editor.putString("location",userInfo.getLocation());
                                                editor.putString("cover_pic",userInfo.coverPic);
                                                editor.putString("sn",userInfo.getUserNumber()+"");
                                                editor.putString("username", userInfo.getUserName());
                                                editor.putString("password", password);
                                                editor.commit();
                                                Utilities.setDatabaseName(getActivity(), userInfo.getDbName());
                                                UtilitiesAdi.setProfileLoaded(getActivity(), false);
                                                Toast.makeText(getActivity(), "Account created successfully.", Toast.LENGTH_LONG).show();

                                                getActivity().runOnUiThread(
                                                        new Runnable() {
                                                            @Override
                                                            public void run() {
                                                                getActivity().getApplicationContext().getSharedPreferences("type",Context.MODE_PRIVATE).edit().putInt("type",STUDENT).commit();
                                                                Intent i=new Intent(getActivity().getApplicationContext(),NavDrawerActivity.class);
                                                                startActivity(i);
                                                                getActivity().finish();
                                                                //getActivity().startActivity(new Intent(getActivity(), NavDrawerActivity.class));
                                                            }
                                                        }
                                                );
                                            }
                                        }
                                    }
                            );
               }
                    }
                }
        );

    }
}
