package com.susankya.schoolvalley;

/**
 * Created by abhinav on 9/16/17.
 */

public class UserToUserChatDetail {
   String text;
   String user1,user2,sentBy;
}
