package com.susankya.schoolvalley;

/**
 * Created by ajay on 8/22/2015.
 */
public class News {
    private int newsSN;
    private String news,date,time;
}
