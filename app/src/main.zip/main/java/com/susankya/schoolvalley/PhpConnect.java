package com.susankya.schoolvalley;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.provider.Settings;
import android.util.Log;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import java.util.HashMap;
import java.util.Map;

public class PhpConnect {
    ConnectOnClickListener mListener;
    private String dialogText,link;
    private Context activity;
    private ProgressDialog dialog;
    private boolean isCancellable;
    private int showDialog;
    private String getOrPost="GET";
    private String[] postParameters,postPlaceholders;
   public PhpConnect(String link,String getDialogText,Context act,int showDialog)
    {
        this.link=link;
        dialogText=getDialogText;
        activity=act;
        isCancellable=false;
        this.showDialog=showDialog;
        dialog=new ProgressDialog(activity);
        dialog.setCancelable(false);
    }
    public PhpConnect(String link,String getDialogText,Context act,int showDialog,String [] parameters,String[]placeholders)
    {
        this.link=Utilities.encodeLinkSpace(link);
        dialogText=getDialogText;
        activity=act;
        this.showDialog=showDialog;
        dialog=new ProgressDialog(activity);
        dialog.setCancelable(false);
        getOrPost="POST";
        isCancellable=false;
        postParameters=parameters;
        postPlaceholders=placeholders;
    }
   public PhpConnect(String link,String getDialogText,Context act,int showDialog,boolean cancellable,String [] parameters,String[]placeholders)
    {
        this.link=Utilities.encodeLinkSpace(link);
        dialogText=getDialogText;
        activity=act;
        this.showDialog=showDialog;
        dialog=new ProgressDialog(activity);
        dialog.setCancelable(false);
        getOrPost="POST";
        isCancellable=cancellable;
        postParameters=parameters;
        postPlaceholders=placeholders;
    }



 interface ConnectOnClickListener {
        void onConnectListener(String res);
    }

    public void setListener(ConnectOnClickListener listener) {
        try
        {
            mListener = listener;
            if(isConnectionAvailable()) // execute();
            {

                StringRequest postRequest = new StringRequest(Request.Method.POST, link,
                        new Response.Listener<String>() {
                            @Override
                            public void onResponse(String response) {
                                try {
response=response.trim().replaceAll("ï»¿","");
                                    //Log.d("fromPost", response);

                                    if(showDialog==1)
                                    dialog.dismiss();
                                    if(activity!=null)
                                    {
                                        mListener.onConnectListener(response);
                                    }

                                }
                                catch (Throwable t)
                                {

                                }

                            }
                        },
                        new Response.ErrorListener() {
                            @Override
                            public void onErrorResponse(VolleyError error) {
                                if(showDialog==1)
                                dialog.dismiss();
                                try {
                                    if(activity!=null)
                                        mListener.onConnectListener(error.toString());
                                }
                                catch (Throwable t)
                                {

                                }


                            }
                        }
                ) {
                    @Override
                    protected Map<String, String> getParams()
                    {
                        Map<String, String>  params = new HashMap<>();
                        // the POST parameters:
                        for(int i=0;i<postPlaceholders.length;i++){
                            params.put(postPlaceholders[i],postParameters[i]);
                            Log.d(postPlaceholders[i],postParameters[i]);

                        }
                        return params;
                    }
                };
                Volley.newRequestQueue(activity).add(postRequest);
                dialog = new ProgressDialog(activity);
                dialog.setMessage(dialogText);
                dialog.setCancelable(isCancellable);
                if(showDialog==1)
                dialog.show();
            }
            else {  AlertDialog.Builder builder1 = new AlertDialog.Builder(activity);
                builder1.setMessage("No Internet connection");
                builder1.setCancelable(true);
                builder1.setPositiveButton("Settings",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                activity.startActivity(new Intent(Settings.ACTION_WIFI_SETTINGS));
                            }
                        });
                AlertDialog alert11 = builder1.create();
                alert11.show();}
               // new AlertDialogBuilder("No Internet connection","Please enable Mobile Data/Wi-Fi in order to log in.","OK","",activity);
        }
        catch (Throwable t)
        {
            //Log.d("phpconnect",t.toString());
        }

    }

    private boolean isConnectionAvailable()
    {
        ConnectivityManager connMgr = (ConnectivityManager)
                activity.getApplicationContext().getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = connMgr.getActiveNetworkInfo();
        if (networkInfo != null && networkInfo.isConnected()) return true;
        else return false;

    }



}
