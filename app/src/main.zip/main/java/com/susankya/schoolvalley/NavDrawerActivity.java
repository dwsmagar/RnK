package com.susankya.schoolvalley;

import android.annotation.TargetApi;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.content.res.TypedArray;
import android.graphics.Bitmap;
import android.graphics.drawable.AnimationDrawable;
import android.graphics.drawable.BitmapDrawable;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.support.design.widget.Snackbar;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.Toast;


import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.ImageRequest;
import com.android.volley.toolbox.Volley;
import com.google.firebase.iid.FirebaseInstanceId;


import org.json.JSONArray;
import org.json.JSONTokener;

import java.util.ArrayList;
import java.util.List;

import static com.android.volley.VolleyLog.TAG;


public class NavDrawerActivity extends AppCompatActivity implements FragmentCodes {
    private static ArrayList<notice> sharedNotices;
    private String[] mNavTiles;
    AnimationDrawable drawable;
    private static int lastFragmentIndex=0;
    Toolbar toolbar;
    View header;
    public static int currentRoutine;
    //BroadcastReceiver onNotice;
    private ListView mDrawerList;
    //private Menu menu;
    private ActionBarDrawerToggle mDrawerToggle;
    private CharSequence mDrawerTitle;
    private TypedArray navMenuIcons;
    private RelativeLayout headerRL;
public static boolean shouldresume;
    private ArrayList<NavDrawerItem> navDrawerItems;
    private NavDrawerListAdapter adapter;
    public static EditText searchEditText;
    private static boolean isShowingSearchEditText;

    public static boolean isShowingSearchEditText() {
        return isShowingSearchEditText;
    }

    public static void setIsShowingSearchEditText(boolean isShowingSearchEditText) {
        NavDrawerActivity.isShowingSearchEditText = isShowingSearchEditText;
    }

    public static EditText getSearchEditText() {
        return searchEditText;
    }

    public static void setSearchEditText(EditText searchEditText) {
        NavDrawerActivity.searchEditText = searchEditText;
    }

    private static boolean isFromDialog=true;
    private boolean doubleBackToExitPressedOnce=false;
    public static boolean isIsFromHome() {
        return isFromHome;
    }
    public void logout()
    {
        new AlertDialog.Builder(this).
                setTitle("Log out")
                .setMessage("Do you really want to log out?")
                .setIcon(android.R.drawable.ic_dialog_alert)
                .setPositiveButton(
                        "Log out",new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                SharedPreferences sharedPreferences1=NavDrawerActivity.this.getApplicationContext().getSharedPreferences("rememberlogin", Context.MODE_PRIVATE);
                                SharedPreferences.Editor editor1=sharedPreferences1.edit();
                                editor1.putBoolean("isloggedin",false);
                                editor1.commit();
                                SharedPreferences sharedPreferences=NavDrawerActivity.this.getApplicationContext().getSharedPreferences("userinfo",Context.MODE_PRIVATE);
                                SharedPreferences.Editor editor=sharedPreferences.edit();
                                editor.remove("name");
                                editor.remove("number");
                                editor.remove("username");
                                editor.remove("password");
                                editor.clear();
                                editor.commit();
                                SharedPreferences shared=NavDrawerActivity.this.getApplicationContext().getSharedPreferences("dbName",Context.MODE_PRIVATE);
                                SharedPreferences.Editor se=shared.edit();
                                se.clear();
                                se.commit();
                                Utilities.setProfilePicThumbnailLoaded(NavDrawerActivity.this.getApplicationContext(), false);
                                startActivity(new Intent(NavDrawerActivity.this, StartActivity.class));

                                dialog.cancel();
                               // startActivity(new Intent(NavDrawerActivity.this,StartActivity.class));
                                NavDrawerActivity.this.finish();
                            }
                        }
                ).setNegativeButton(
                "Cancel",new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                    }
                }
        ).show();

    }
    public static void setIsFromHome(boolean isFromHome) {
        NavDrawerActivity.isFromHome = isFromHome;
    }

    private static boolean isFromHome;
    public static void setIsFromDialog(boolean isFromDialog) {
        NavDrawerActivity.isFromDialog = isFromDialog;
    }

    public static boolean isIsFromDialog() {

        return isFromDialog;
    }
    private static LinearLayout motherView;
   public int getPreviousIndex() {
        return previousIndex;
    }



    private SharedPreferences sp;
    private CharSequence mTitle;

private static ArrayList<View> views=new ArrayList();
    public static int getZugad() {
        return zugad;
    }

    public static void setZugad(int zugada) {
        zugad = zugada;
    }
private    boolean isNoticeNotificationOn;
 private static int zugad=0;


    private static ArrayList<question> sharedQuestions;
    public static ArrayList<question> getSharedQuestions() {
        return sharedQuestions;
    }
    public static void setSharedQuestions(ArrayList<question> sharedQuestionsa) {
        sharedQuestions = sharedQuestionsa;
    }

public static void setViewListValue(int index,View v){
   views.add(index,v);
}
    public void showSearch(){
        searchEditText.setVisibility(View.VISIBLE);
        isShowingSearchEditText=true;
        searchEditText.requestFocus();
        InputMethodManager imm = (InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE);
        imm.showSoftInput(searchEditText, InputMethodManager.SHOW_IMPLICIT);
    }
    public static void hideSearch(){
        searchEditText.setVisibility(View.GONE);
        isShowingSearchEditText=false;
    }
 public void setIndex(int index) {
        this.index = index;
    }

    public int index=0,previousIndex;
    public boolean loggedIn;

    public void setLoggedIn(boolean loggedIn) {
        this.loggedIn = loggedIn;
    }

    public static NavDrawerActivity app;
    private DrawerLayout mDrawerLayout;
    public  void selectItem(int position) {
        shouldresume=true;
        --position;
        Fragment fragment=null;
        previousIndex=index;
        index=position;
      if(type==STUDENT)
            fragment=studentCase(position);
      else if(type==ADMIN)
        fragment=AdminCase(position);

        if(fragment!=null)
        {
            FragmentManager fragmentManager = getSupportFragmentManager();
            if(!(lastFragmentIndex==index)){
            fragmentManager.beginTransaction().replace(R.id.content_frame, fragment, Integer.toString(position)).addToBackStack(null).commit();
                //Log.d("TAG", "selectItem: "+fragmentManager.getBackStackEntryCount());
        }
            else{
                fragmentManager.beginTransaction().replace(R.id.content_frame, fragment, Integer.toString(position)).addToBackStack(null).commit();
                //Log.d("TAG", "selectItem: "+fragmentManager.getBackStackEntryCount());

            }
        }
        lastFragmentIndex=index;
    }

    public Fragment studentCase(int position)
    {
        hideSearch();
        switch (position)
        {
            case 0:
                NavDrawerActivity.getSearchEditText().setHint("Search");
                return new HomeTabsFragment();
            case 1:
            {
                if(Utilities.isConnectionAvailable(NavDrawerActivity.this))
                {
                    Intent i=new Intent(NavDrawerActivity.this,SchoolProfileActivity.class);
                    Bundle b=new Bundle();
                    b.putString("name",Utilities.getInstitution(getApplicationContext()));
                    b.putString("location",Utilities.getLocation(getApplicationContext()));
                    b.putString("SN",UtilitiesAdi.giveMeSN(getApplicationContext(),Utilities.getDatabaseName(getApplicationContext())));
                    b.putString("url",Utilities.getCoverPicURL(getApplicationContext()));
                    b.putString("dbName",Utilities.getDatabaseName(getApplicationContext()));
                    i.putExtras(b);
                    startActivity(i);

                }
                else
                Toast.makeText(getApplicationContext(),"No internet connection",Toast.LENGTH_LONG).show();
                return null;

            }
            case 2:
                return new StudentProfileFragment();
            case 3:
               startActivity(new Intent(this,SearchableActivity.class));
                return null;
            case 4:
                return new NewSettingsFragment();
            case 5: {
             //   Toast.makeText(getApplicationContext(),Utilities.getSN(getApplicationContext())+ UtilitiesAdi.giveMeSN(getApplicationContext(), Utilities.getDatabaseName(getApplicationContext())),Toast.LENGTH_SHORT).show();
              //  return ChatFragment.newInstance(Utilities.getSN(getApplicationContext()), UtilitiesAdi.giveMeSN(getApplicationContext(), Utilities.getDatabaseName(getApplicationContext())),Utilities.getCollegeName(getApplicationContext()));
                if (!(Utilities.getBlocked(getApplicationContext()) == 0)) {
                    Snackbar.make(motherView, "You have been blocked by the admin.", Snackbar.LENGTH_LONG).show();
                    return null;
                }
               /* return ChatFragment.newInstance(Utilities.getSN(getApplicationContext()),
                        UtilitiesAdi.giveMeSN(getApplicationContext(), Utilities.getDatabaseName(getApplicationContext())),
                        Utilities.getInstitution(getApplicationContext()));*/
                return new StudentChatListFragment();

            }
            case 6:
                return new NewAboutUsFragment();
            default:
            return new BlankFragment();
        }

    }

    public Fragment AdminCase(int position)
    {
        hideSearch();
        switch (position)
        {

            case 0:
                NavDrawerActivity.getSearchEditText().setHint("Search");
                return new AdminTabsFragment();
            case 1:
            {
                if(Utilities.isConnectionAvailable(NavDrawerActivity.this))
                {
                    Intent i=new Intent(NavDrawerActivity.this,SchoolProfileActivity.class);
                    Bundle b=new Bundle();
                    b.putString("name",Utilities.getInstitution(getApplicationContext()));
                    b.putString("location",Utilities.getLocation(getApplicationContext()));
                    b.putString("SN",UtilitiesAdi.giveMeSN(getApplicationContext(),Utilities.getDatabaseName(getApplicationContext())));
                    b.putString("url",Utilities.getCoverPicURL(getApplicationContext()));
                    b.putString("dbName",Utilities.getDatabaseName(getApplicationContext()));
                    i.putExtras(b);
                    startActivity(i);
                }
                else {
                    Toast.makeText(getApplicationContext(), "No internet connection", Toast.LENGTH_LONG).show();
                }return null;

            }
            case 2:
                startActivity(new Intent(this,SearchableActivity.class));
            case 3:
                return new NewSettingsFragment();
            case 4:
                return new SubscribedUserListFragment();
            case 5:
            {
                return new ChatListFragment();
            }
            case 6:
                return new NewAboutUsFragment();
            default:
                return new BlankFragment();

        }

    }

    public Bitmap getCircularImage(Bitmap b,int radius)
    {
        return RoundedImageView.getCroppedBitmap(b, radius);
    }

    public void updateHeader()
    {
        TextViewPlus fullNameUser=(TextViewPlus)header.findViewById(R.id.name);
        TextViewPlus userNameUser=(TextViewPlus)header.findViewById(R.id.username);
        TextViewPlus instName=(TextViewPlus) header.findViewById(R.id.instname);
        TextViewPlus circleTv=(TextViewPlus)header.findViewById(R.id.circle_head_tv);
      // final ImageView img=(ImageView)header.findViewById(R.id.img);
        circleTv.setCustomFont(getApplicationContext(),BOLD);
        circleTv.setText(Utilities.getInstitution(getApplicationContext()).substring(0,1));
        instName.setCustomFont(getApplicationContext(),BOLD);
        userNameUser.setCustomFont(getApplicationContext(),REGULAR);
        fullNameUser.setCustomFont(getApplicationContext(),REGULAR);
        if(!Utilities.getUsername(this).isEmpty())
        {
            if(type==STUDENT)
            {
                userNameUser.setText("@"+Utilities.getUsername(this));
                fullNameUser.setText(Utilities.getFullname(this));
            }
            else {
                userNameUser.setText("@" + Utilities.getUsername(this));
                fullNameUser.setVisibility(View.GONE);
            }

               if(Utilities.getProfilePicThumbnailLoaded(getApplicationContext())) {
                   Bitmap b= Utilities.loadImageFromStorage(getApplicationContext(), Utilities.getUsername(getApplicationContext()) + "thumbnail.jpg");
                   Bitmap blurred= b;// fastblur(b,1,20);
                   header.setBackground(new BitmapDrawable(blurred));

                   adapter.notifyDataSetChanged();
               }
            else
               {

                ImageRequest imgRequest = new ImageRequest(Utilities.encodeLinkSpace(Utilities.getCoverPicURL(getApplicationContext())),
                        new Response.Listener<Bitmap>() {
                            @Override
                            public void onResponse(Bitmap loadedImage) {
                              //  Bitmap b=getCircularImage(loadedImage, SIZE);
                                Bitmap blurred=loadedImage;//fastblur(loadedImage,1,20);

                                BitmapDrawable bd=new BitmapDrawable(blurred);
                                header.setBackground(bd);
                                adapter.notifyDataSetChanged();
                                Utilities.saveToInternalStorage(getApplicationContext(), loadedImage, Utilities.getUsername(getApplicationContext()) + "thumbnail.jpg");
                                Utilities.setProfilePicThumbnailLoaded(getApplicationContext(), true);
                            }
                        }, 0, 0, ImageView.ScaleType.FIT_XY, Bitmap.Config.ARGB_8888, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        error.printStackTrace();
                    }
                });
                Volley.newRequestQueue(getApplicationContext()).add(imgRequest);
            }




            instName.setText(Utilities.getInstitution(this));

        }
        else
        {
            fullNameUser.setText("Sign in for full access");
            userNameUser.setText("");
            fullNameUser.setOnClickListener(
                    new View.OnClickListener()
                    {
                        @Override
                        public void onClick(View v) {
                            startActivity(new Intent(NavDrawerActivity.this, StudentInActivity.class));
                        }
                    }
            );
            userNameUser.setClickable(false);

        }

    }



    @Override
    protected void onResume() {
        super.onResume();
        updateHeader();
    }

    @Override
    public boolean onSearchRequested() {

    return super.onSearchRequested();
    }
    int type;
    @TargetApi(Build.VERSION_CODES.JELLY_BEAN)
    @Override
    protected void onCreate(Bundle savedInstanceState) {

       // getSupportActionBar().hide();
        super.onCreate(savedInstanceState);
       // fcmToken.onTokenRefresh();
        String token = FirebaseInstanceId.getInstance().getToken();

        //Log.d("TAG", "onCreate: "+token);
        app=NavDrawerActivity.this;
        drawable= (AnimationDrawable) getResources().getDrawable(R.drawable.animation);
        setContentView(R.layout.activity_tab);
        motherView=(LinearLayout)findViewById(R.id.motherLayout);
        toolbar = (Toolbar) findViewById(R.id.toolbar);
        searchEditText=(EditText)toolbar.findViewById(R.id.search_et);
       setSupportActionBar(toolbar);
        SharedPreferences loginTypeSP=this.getApplicationContext().getSharedPreferences("type",Context.MODE_PRIVATE);
        type=loginTypeSP.getInt("type",2);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
getSupportActionBar().setHomeButtonEnabled(true);
     mDrawerLayout=(DrawerLayout)findViewById(R.id.drawer_layout);
        mTitle = mDrawerTitle = getTitle();
        mDrawerList = (ListView) findViewById(R.id.left_drawer);
        navDrawerItems = new ArrayList<NavDrawerItem>();
        adapter = new NavDrawerListAdapter(getApplicationContext(),
                navDrawerItems);
        header=getLayoutInflater().inflate(R.layout.material_nav_header,null,false);
        final ImageButton logout=(ImageButton)header.findViewById(R.id.logout_header);
        final TextViewPlus tvpOFSchoolCode=(TextViewPlus)header.findViewById(R.id.schoolCode);
        final String code=getSharedPreferences(EnterCodeFragment.SCHOOL_CODE_PREF,MODE_PRIVATE).getString(EnterCodeFragment.SCHOOL_CODE,"");
        if(!code.equals(""))
            tvpOFSchoolCode.setText("Access Code: "+code);
        else
        tvpOFSchoolCode.setVisibility(View.GONE);
        logout.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        logout();
                    }
                }
        );

        mDrawerList.addHeaderView(header);
        mDrawerToggle = new ActionBarDrawerToggle(this, mDrawerLayout, //nav menu toggle icon
                R.string.app_name, R.string.app_name // nav drawer open - description for accessibility
        ){
            public void onDrawerClosed(View view) {
               // getSupportActionBar().setTitle(mTitle);
                // calling onPrepareOptionsMenu() to show action bar icons
                invalidateOptionsMenu();
            }

            public void onDrawerOpened(View drawerView) {
                //getSupportActionBar().setTitle(mDrawerTitle);
                // calling onPrepareOptionsMenu() to hide action bar icons
                invalidateOptionsMenu();
            }
        };
        mDrawerToggle.setHomeAsUpIndicator(getResources().getDrawable(R.drawable.nav_drawer_long_icon));
        mDrawerToggle.setDrawerIndicatorEnabled(true);
        mDrawerLayout.setDrawerListener(mDrawerToggle);
        mDrawerList.setOnItemClickListener(new SlideMenuClickListener());
        mDrawerList.setAdapter(adapter);
        sp=getSharedPreferences(PUBLIC_SHAREDPREFERENCE, Context.MODE_PRIVATE);
        sp.edit().putBoolean(NewNoticeService.HAS_SENT_NOTIFICATION,false).commit();
        sp.edit().putInt(NewNoticeService.NOTICE_NUMBER_OF_LAST_NOTIFICATION,0);
          isNoticeNotificationOn =sp.getBoolean(SettingsFragment.SETTINGS_NOTICE,true);
           if(!NewNoticeService.isServiceAlarmOn(getApplicationContext())&& isNoticeNotificationOn)
        {
           NewNoticeService.setServiceAlarm(getApplicationContext(), true);
        }
            //getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        try {
            Class.forName("android.os.AsyncTask");
            } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
      //  navManagerAdmin();

        if(type==ADMIN)
        {
            navManagerAdmin();

        }
        else if (type==STUDENT)
        {
            navManagerStudent();
        }

      // else this.finish();

        if (savedInstanceState == null) {
            // on first time display view for first nav item
            selectItem(1);
        }
       // navMenuIcons.recycle();
        if(getIntent()!=null){
try{
    if(getIntent().getStringExtra(MyFirebaseMessagingService.ACTION).equals(MyFirebaseMessagingService.ACTION_CHAT)){
        //Log.d("TAG", "onCreate: got");
        Fragment fragment;
        if(type==STUDENT)
            fragment=ChatFragment.newInstance(Utilities.getSN(getApplicationContext()), UtilitiesAdi.giveMeSN(getApplicationContext(), Utilities.getDatabaseName(getApplicationContext())),Utilities.getInstitution(getApplicationContext()));
        else if(type==ADMIN)
            fragment=new ChatListFragment();
        else
            fragment=new BlankFragment();
        getSupportFragmentManager().beginTransaction().replace(R.id.content_frame,fragment).addToBackStack(null).commit();

    }
}catch (Exception e){
    //Log.d(TAG, "onCreate: "+e.toString());
}
            boolean c=sp.getBoolean("abcd",false);
                    if(c){
                  sp.edit().putBoolean("abcd",false).commit();
                 selectItem(1);
            }
            boolean d=sp.getBoolean("susankya",false);
            if(d){
                sp.edit().putBoolean("susankya",false).commit();
                getSupportFragmentManager().beginTransaction().replace(R.id.content_frame, new SusankyaNotice()).addToBackStack(null).commit();
            }
        }

     /*   onNotice = new BroadcastReceiver() {

            @Override
            public void onReceive(Context context, Intent intent) {
          menu.getItem(1).setIcon(getResources().getDrawable(R.drawable.ic_chat_alert));
            }
        };
       registerReceiver(onNotice, new IntentFilter(MyFirebaseMessagingService.BROADCAST_ACTION_activity));*/
    }

    void navManagerStudent()
    {
        mNavTiles = getResources().getStringArray(R.array.nav_tiles_student);
        navMenuIcons = getResources()
                .obtainTypedArray(R.array.nav_drawer_icons_student);
        for(int i=0;i<mNavTiles.length;i++)
        {
            navDrawerItems.add(new NavDrawerItem(mNavTiles[i], navMenuIcons.getResourceId(i, -1)));
        }

       updateHeader();
        // nav drawer icons from resources

        // Recycle the typed array

    }
    void navManagerAdmin()
    {
        mNavTiles = getResources().getStringArray(R.array.nav_tiles_admin);
        navMenuIcons = getResources()
                .obtainTypedArray(R.array.nav_drawer_icons_admin);
        for(int i=0;i<mNavTiles.length;i++)
        {
            navDrawerItems.add(new NavDrawerItem(mNavTiles[i], navMenuIcons.getResourceId(i, -1)));
        }
       updateHeader();

        // nav drawer icons from resources

        // Recycle the typed array

    }
private void changeFontColor(int index){
    mDrawerList.getAdapter().getItem(index);
}
    private class SlideMenuClickListener implements
            ListView.OnItemClickListener {
        @Override
        public void onItemClick(AdapterView<?> parent, View view, int position,
                                long id) {
            if(!(position==0))
            {
                mDrawerLayout.closeDrawer(mDrawerList);
                // display view for selected nav drawer item
                selectItem(position);
            }

        }
    }



    public boolean isLoggedIn() {
        return sp.getBoolean("loggedin", false);
    }
    public void setArrayList(ArrayList<notice> notices)
    {
        sharedNotices=notices;
    }
    public static ArrayList<notice> getArrayList()
    {
        return sharedNotices;
    }
    @Override
    protected void onPostCreate(Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);
        mDrawerToggle.syncState();
        // Sync the toggle state after onRestoreInstanceState has occurred.
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        mDrawerToggle.onConfigurationChanged(newConfig);

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()){
          /*case R.id.action_search:
            {
                startActivity(new Intent(this,SearchableActivity.class));
                return true;
        }*/
            case android.R.id.home: {
                mDrawerLayout.openDrawer(GravityCompat.START);
                return true;// OPEN DRAWER
            }
            case R.id.action_chat:
            {
                //menu.getItem(1).setIcon(getResources().getDrawable(R.drawable.ic_chat));
                try{
                //unregisterReceiver(onNotice);
                }catch (Exception e){
                    //Log.d(TAG, "onOptionsItemSelected: "+e.toString());
                }
                if(!(Utilities.getBlocked(getApplicationContext())==0)){
                    Snackbar.make(motherView,"You have been blocked by the admin.",Snackbar.LENGTH_LONG).show();

                    return false;}
                Fragment fragment;
                if(type==STUDENT)
                    fragment=ChatFragment.newInstance(Utilities.getSN(getApplicationContext()), UtilitiesAdi.giveMeSN(getApplicationContext(), Utilities.getDatabaseName(getApplicationContext())),Utilities.getInstitution(getApplicationContext()));
                else if(type==ADMIN)
                    fragment=new ChatListFragment();
                else
                fragment=new BlankFragment();
getSupportFragmentManager().beginTransaction().replace(R.id.content_frame,fragment).addToBackStack(null).commit();
                return true;
            }

        }
        // Handle your other action bar items...

        return super.onOptionsItemSelected(item);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        /*getMenuInflater().inflate(R.menu.menu_nav_drawer, menu);
        this.menu=menu;*/
        return true;
    }


    /* Called whenever we call invalidateOptionsMenu() */
    @Override
    public boolean onPrepareOptionsMenu(Menu menu) {
        // If the nav drawer is open, hide action items related to the content view

        // menu.findItem(R.id.action_settings).setVisible(!drawerOpen);
        return super.onPrepareOptionsMenu(menu);
    }



    public Animation getAnimation(){
        Animation animation = AnimationUtils.loadAnimation(this, R.anim.slide_in_from_right);
    return  animation;
    }


    /** Swaps fragments in the main content view */


    public void onSectionAttached(int number) {
        mTitle = mNavTiles[number];

    }


    public void setTitle() {

        //getSupportActionBar().setTitle(mTitle);
    }
    public void setTitle(CharSequence title)
    {
        mTitle=title;
    getSupportActionBar().setTitle(mTitle);
    }

   @Override
    public void onBackPressed(){
       if(isShowingSearchEditText()){
       searchEditText.setVisibility(View.GONE);
       searchEditText.setText("");
           isShowingSearchEditText=false;
       return;
       }else
       searchEditText.setText("");
       //Toast.makeText(getApplicationContext(),"Pressed",Toast.LENGTH_SHORT).show();
       FragmentManager fm=getSupportFragmentManager();
       if(!getSharedPreferences("rememberlogin", Context.MODE_PRIVATE).getBoolean("isloggedin",false))
           this.finish();
        if(fm.getBackStackEntryCount()==1){
           if (doubleBackToExitPressedOnce) {
               super.onBackPressed();
               this.finish();
               return;
           }
           this.doubleBackToExitPressedOnce = true;
           Toast.makeText(this, "Please click BACK again to exit", Toast.LENGTH_SHORT).show();
           new Handler().postDelayed(new Runnable() {

               @Override
               public void run() {
                   doubleBackToExitPressedOnce=false;
               }
           }, 2000);
       }
     else  if (fm.getBackStackEntryCount()>1) {
           fm.popBackStack();
            }
       else
           super.onBackPressed();

        }

}
