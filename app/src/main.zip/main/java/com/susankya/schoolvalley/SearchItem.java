package com.susankya.schoolvalley;

/**
 * Created by Aditya on 12/30/2016.
 */
public class SearchItem {

    public String name,location,username,URL,dbname;
    public int collegeSN;


}
